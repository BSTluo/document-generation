# 是一个文档生成器？

```
npm i // 安装依赖
npm run start//启动它
```
# 运行效果
### 生成的json
![]('./src/json.png')
### 生成的Markdown
![]('./src/md.png')

### data文件夹内的是示例